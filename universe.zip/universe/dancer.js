﻿/**
 * dancer.js
 * Personaje 2D de Michael Jackson con pasos de baile interactivos.
 * Controles: flechas = mover | 1-8 = pasos | 0 = idle
 */
(function () {
  "use strict";

  const canvas = document.getElementById("stage-canvas");
  const ctx    = canvas.getContext("2d");
  const label  = document.getElementById("move-label");

  // Resolución real del canvas
  let CW = canvas.offsetWidth;
  let CH = canvas.offsetHeight;
  canvas.width  = CW;
  canvas.height = CH;

  window.addEventListener("resize", function() {
    CW = canvas.offsetWidth;
    CH = canvas.offsetHeight;
    canvas.width  = CW;
    canvas.height = CH;
    mj.x = Math.max(60, Math.min(CW - 60, mj.x));
    mj.y = Math.max(80, Math.min(CH - 20, mj.y));
  });

  /* ── Colores MJ ─────────────────────────────────── */
  var C = {
    skin:    "#c8956c",
    hat:     "#111111",
    jacket:  "#cc0000",
    jacket2: "#aa0000",
    pants:   "#111111",
    sock:    "#eeeeee",
    shoe:    "#111111",
    glove:   "#ffffff",
    gold:    "#ffd700",
    belt:    "#ffd700",
  };

  /* ── Estado del personaje ─────────────────────── */
  var mj = {
    x:       0,
    y:       0,
    facing:  1,      // 1=derecha, -1=izquierda
    speed:   4,
    move:    "idle",
    frame:   0,
    keys:    {},
    sparkles: [],
    footDust: [],
  };

  /* ── Pasos de baile ─────────────────────────────── */
  var MOVES = {
    "idle":        { name: "Idle",            frames: 60,  loop: true  },
    "moonwalk":    { name: "Moonwalk 🌙",      frames: 48,  loop: true  },
    "thriller":    { name: "Thriller Walk 🧟", frames: 40,  loop: true  },
    "lean":        { name: "Lean ↗",           frames: 60,  loop: true  },
    "toestand":    { name: "Toe Stand 🩰",      frames: 50,  loop: true  },
    "spin":        { name: "Spin 360° 🌀",      frames: 36,  loop: true  },
    "robot":       { name: "Robot 🤖",          frames: 40,  loop: true  },
    "crotch":      { name: "Crotch Grab 🎤",    frames: 50,  loop: true  },
    "smooth":      { name: "Smooth Criminal ↙", frames: 60,  loop: true  },
  };

  var KEY_TO_MOVE = {
    "1": "moonwalk",
    "2": "thriller",
    "3": "lean",
    "4": "toestand",
    "5": "spin",
    "6": "robot",
    "7": "crotch",
    "8": "smooth",
    "0": "idle",
  };

  /* ── Input ───────────────────────────────────────── */
  document.addEventListener("keydown", function(e) {
    mj.keys[e.key] = true;

    if (KEY_TO_MOVE[e.key] !== undefined) {
      setMove(KEY_TO_MOVE[e.key]);
      e.preventDefault();
    }
    if (["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].indexOf(e.key) > -1) {
      e.preventDefault();
    }
  });
  document.addEventListener("keyup", function(e) {
    mj.keys[e.key] = false;
  });

  function setMove(name) {
    if (mj.move === name) return;
    mj.move  = name;
    mj.frame = 0;
    // Iluminar item activo en panel
    document.querySelectorAll(".move-item").forEach(function(el) {
      el.classList.toggle("active", el.dataset.key === Object.keys(KEY_TO_MOVE).find(function(k){ return KEY_TO_MOVE[k] === name; }));
    });
    showLabel(MOVES[name].name);
    // Spawn sparkles
    spawnSparkles(8);
  }

  function showLabel(text) {
    label.textContent = text;
    label.classList.add("show");
    clearTimeout(label._t);
    label._t = setTimeout(function(){ label.classList.remove("show"); }, 2000);
  }

  /* ── Sparkles ──────────────────────────────────── */
  function spawnSparkles(n) {
    for (var i = 0; i < n; i++) {
      mj.sparkles.push({
        x:     mj.x + (Math.random()-0.5)*40,
        y:     mj.y - 60 - Math.random()*40,
        vx:    (Math.random()-0.5)*3,
        vy:    -Math.random()*3-1,
        life:  1,
        r:     Math.random()*3+1,
        hue:   Math.random() > 0.5 ? 45 : 0,
      });
    }
  }

  function spawnDust() {
    mj.footDust.push({
      x:    mj.x + (Math.random()-0.5)*20,
      y:    mj.y,
      vx:   (Math.random()-0.5)*2,
      vy:   -Math.random()*1.5,
      life: 1,
      r:    Math.random()*4+2,
    });
  }

  /* ══════════════════════════════════════════════════
     DIBUJO DEL PERSONAJE — Sistema de segmentos
     Cada pose define ángulos relativos de miembros
  ══════════════════════════════════════════════════ */

  function drawMJ(x, y, f, move, frame) {
    ctx.save();
    ctx.translate(x, y);
    if (mj.facing === -1) ctx.scale(-1, 1);

    var t = frame / 60; // tiempo normalizado 0..1+

    // Sombra del suelo
    ctx.beginPath();
    ctx.ellipse(0, 2, 28, 7, 0, 0, Math.PI*2);
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fill();

    switch(move) {
      case "moonwalk":   drawMoonwalk(t);   break;
      case "thriller":   drawThriller(t);   break;
      case "lean":       drawLean(t);       break;
      case "toestand":   drawToeStand(t);   break;
      case "spin":       drawSpin(t);       break;
      case "robot":      drawRobot(t);      break;
      case "crotch":     drawCrotchGrab(t); break;
      case "smooth":     drawSmooth(t);     break;
      default:           drawIdle(t);       break;
    }

    ctx.restore();
  }

  /* ─── Funciones de dibujado de partes ─────────── */

  function drawTorso(jacketColor) {
    ctx.fillStyle = jacketColor || C.jacket;
    ctx.beginPath();
    ctx.roundRect(-14, -70, 28, 38, 4);
    ctx.fill();
    // Línea central chaqueta
    ctx.strokeStyle = C.jacket2;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -70); ctx.lineTo(0, -33);
    ctx.stroke();
    // Botones dorados
    ctx.fillStyle = C.gold;
    ctx.beginPath(); ctx.arc(-6, -58, 2, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(6,  -58, 2, 0, Math.PI*2); ctx.fill();
  }

  function drawHead(hatAngle) {
    hatAngle = hatAngle || 0;
    // Cuello
    ctx.fillStyle = C.skin;
    ctx.beginPath();
    ctx.roundRect(-5, -80, 10, 14, 2);
    ctx.fill();
    // Cabeza
    ctx.fillStyle = C.skin;
    ctx.beginPath();
    ctx.ellipse(0, -95, 16, 18, 0, 0, Math.PI*2);
    ctx.fill();
    // Gafas
    ctx.fillStyle = "rgba(0,0,0,0.85)";
    ctx.beginPath(); ctx.roundRect(-14, -100, 11, 7, 3); ctx.fill();
    ctx.beginPath(); ctx.roundRect(3, -100, 11, 7, 3);   ctx.fill();
    ctx.strokeStyle = "#555"; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(-3,-96); ctx.lineTo(3,-96); ctx.stroke();
    // Sombrero
    ctx.save();
    ctx.translate(0, -108);
    ctx.rotate(hatAngle);
    ctx.fillStyle = C.hat;
    ctx.beginPath();
    ctx.roundRect(-16, -24, 32, 26, 3);
    ctx.fill();
    ctx.fillStyle = "#1a1a1a";
    ctx.beginPath();
    ctx.ellipse(0, 2, 22, 6, 0, 0, Math.PI*2);
    ctx.fill();
    // Banda del sombrero
    ctx.fillStyle = C.gold;
    ctx.fillRect(-16, -4, 32, 3);
    ctx.restore();
  }

  function drawArm(side, shoulderAngle, elbowAngle, glove) {
    // side: 1=right, -1=left
    var sx = side * 14;
    ctx.save();
    ctx.translate(sx, -65);
    ctx.rotate(shoulderAngle);
    // Brazo superior
    ctx.fillStyle = C.jacket;
    ctx.beginPath();
    ctx.roundRect(-4, 0, 9, 22, 4);
    ctx.fill();
    ctx.translate(0, 22);
    ctx.rotate(elbowAngle);
    // Antebrazo
    ctx.fillStyle = C.jacket;
    ctx.beginPath();
    ctx.roundRect(-4, 0, 9, 18, 4);
    ctx.fill();
    ctx.translate(0, 18);
    // Mano / guante
    ctx.fillStyle = glove ? C.glove : C.skin;
    ctx.beginPath();
    ctx.ellipse(0, 5, 6, 7, 0, 0, Math.PI*2);
    ctx.fill();
    if (glove) {
      // Brillos del guante
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.beginPath(); ctx.ellipse(-2, 2, 2, 3, -0.3, 0, Math.PI*2); ctx.fill();
    }
    ctx.restore();
  }

  function drawLeg(side, hipAngle, kneeAngle, toeUp) {
    var lx = side * 8;
    ctx.save();
    ctx.translate(lx, -32);
    ctx.rotate(hipAngle);
    // Muslo
    ctx.fillStyle = C.pants;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 11, 26, 4);
    ctx.fill();
    ctx.translate(0, 26);
    ctx.rotate(kneeAngle);
    // Espinilla
    ctx.fillStyle = C.pants;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 11, 22, 4);
    ctx.fill();
    ctx.translate(0, 22);
    // Calcetín blanco
    ctx.fillStyle = C.sock;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 11, 10, 2);
    ctx.fill();
    ctx.translate(0, 10);
    // Zapato
    ctx.save();
    if (toeUp) ctx.rotate(-0.3);
    ctx.fillStyle = C.shoe;
    ctx.beginPath();
    ctx.ellipse(2, 4, 11, 5, 0.1, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();
    ctx.restore();
  }

  function drawBelt() {
    ctx.fillStyle = C.gold;
    ctx.beginPath();
    ctx.roundRect(-14, -35, 28, 5, 2);
    ctx.fill();
    ctx.fillStyle = "#aa8800";
    ctx.beginPath();
    ctx.roundRect(-4, -37, 8, 8, 1);
    ctx.fill();
  }

  /* ══════════════════════════════════════════════════
     POSES POR MOVIMIENTO
  ══════════════════════════════════════════════════ */

  function drawIdle(t) {
    var bob = Math.sin(t * Math.PI * 2) * 0.05;
    ctx.translate(0, Math.sin(t*Math.PI*2)*2);
    drawLeg(-1, bob, 0, false);
    drawLeg(1, -bob, 0, false);
    drawTorso();
    drawBelt();
    drawArm(-1, 0.2 + bob, 0.1, false);
    drawArm(1, -0.2 - bob, 0.1, true);
    drawHead(Math.sin(t*Math.PI*2)*0.05);
  }

  // 1. MOONWALK
  function drawMoonwalk(t) {
    var p = (t * 2) % 1;
    var leg1Hip = -0.3 + Math.sin(p * Math.PI * 2) * 0.4;
    var leg2Hip =  0.3 - Math.sin(p * Math.PI * 2) * 0.4;
    var leg1Knee= Math.max(0, Math.sin(p * Math.PI * 2 + 1) * 0.5);
    var leg2Knee= Math.max(0, Math.sin(p * Math.PI * 2 - 1) * 0.5);
    // Deslizamiento moonwalk (hacia atrás)
    drawLeg(-1, leg1Hip, leg1Knee, leg1Knee < 0.1);
    drawLeg(1,  leg2Hip, leg2Knee, leg2Knee < 0.1);
    drawTorso();
    drawBelt();
    drawArm(-1, 0.3, 0.2, false);
    drawArm(1, -0.3, 0.2, true);
    drawHead(Math.sin(t*Math.PI)*0.08);
    if (Math.random() < 0.15) spawnDust();
  }

  // 2. THRILLER WALK
  function drawThriller(t) {
    var p = (t * 1.5) % 1;
    var sin = Math.sin(p * Math.PI * 2);
    drawLeg(-1, 0.4 * sin, 0.3, false);
    drawLeg(1, -0.4 * sin, 0.3, false);
    ctx.translate(0, Math.abs(sin)*3);
    drawTorso("#2a0000");  // chaqueta oscura para Thriller
    drawBelt();
    // Brazos de zombie
    drawArm(-1, -1.2, -0.5, false);
    drawArm(1,  -1.2, -0.5, true);
    drawHead(sin * 0.15);
  }

  // 3. LEAN
  function drawLean(t) {
    var lean = Math.sin(t * Math.PI * 2) * 0.45;
    ctx.rotate(lean);
    drawLeg(-1, -0.15, 0.1, false);
    drawLeg(1,  0.15, 0.1, true);
    drawTorso();
    drawBelt();
    drawArm(-1, 0.6, 0.3, false);
    drawArm(1, -0.6, 0.3, true);
    drawHead(-lean * 0.3);
    if (Math.abs(Math.sin(t*Math.PI*2)) > 0.9 && Math.random()<0.2) spawnSparkles(2);
  }

  // 4. TOE STAND
  function drawToeStand(t) {
    var phase = (t * 1.2) % 1;
    var up = Math.sin(phase * Math.PI);
    ctx.translate(0, -up * 18);
    drawLeg(-1, 0, 0, true);
    drawLeg(1,  0, 0, true);
    drawTorso();
    drawBelt();
    var armSwing = Math.sin(t * Math.PI * 2) * 0.4;
    drawArm(-1, armSwing, 0.2, false);
    drawArm(1, -armSwing, 0.2, true);
    drawHead(0);
    if (up > 0.8 && Math.random() < 0.1) spawnSparkles(3);
  }

  // 5. SPIN 360
  function drawSpin(t) {
    var angle = (t * 3) % 1 * Math.PI * 2;
    ctx.rotate(angle * 0.1);
    var squeeze = 0.6 + 0.4 * Math.abs(Math.cos(angle));
    ctx.scale(squeeze, 1);
    drawLeg(-1, -0.2, 0.1, false);
    drawLeg(1,  0.2, 0.1, false);
    drawTorso();
    drawBelt();
    drawArm(-1, -0.8, 0.3, false);
    drawArm(1,  0.8, 0.3, true);
    drawHead(angle * 0.05);
    if (Math.random() < 0.25) spawnSparkles(2);
  }

  // 6. ROBOT
  function drawRobot(t) {
    var step = Math.floor(t * 4) % 4;
    var legL = step === 0 ? -0.3 : step === 2 ? 0.3 : 0;
    var legR = step === 1 ? -0.3 : step === 3 ? 0.3 : 0;
    var armL = step === 0 ? -0.8 : step === 2 ? 0 : -0.4;
    var armR = step === 1 ?  0.8 : step === 3 ? 0 :  0.4;
    drawLeg(-1, legL, 0, false);
    drawLeg(1,  legR, 0, false);
    drawTorso("#1a1a1a");  // robot look oscuro
    drawBelt();
    drawArm(-1, armL, 0, false);
    drawArm(1,  armR, 0, true);
    drawHead(step % 2 === 0 ? 0.1 : -0.1);
  }

  // 7. CROTCH GRAB
  function drawCrotchGrab(t) {
    var p = Math.sin(t * Math.PI * 2);
    ctx.translate(0, p * 3);
    drawLeg(-1, -0.2 + p*0.1, 0.15, false);
    drawLeg(1,  0.2 - p*0.1, 0.15, true);
    drawTorso();
    drawBelt();
    // Brazo derecho hacia crotch, izquierdo al aire
    drawArm(-1, -1.0, -0.6, false);
    drawArm(1, 0.5 + p*0.2, 0.8, true);
    drawHead(0.1);
    if (p > 0.8 && Math.random() < 0.3) spawnSparkles(3);
  }

  // 8. SMOOTH CRIMINAL
  function drawSmooth(t) {
    var phase = (t * 1.2) % 1;
    var lean  = 0.3 + Math.sin(phase * Math.PI) * 0.25;
    // Lean extremo hacia adelante (el efecto anti-gravedad)
    ctx.rotate(lean);
    drawLeg(-1, -0.2, 0.2, true);
    drawLeg(1,  0.3, 0.1, true);
    drawTorso("#fff");  // traje blanco
    drawBelt();
    drawArm(-1, 1.0, 0.4, true);  // ambos guantes
    drawArm(1, -1.0, 0.4, true);
    drawHead(-lean * 0.4);
    if (lean > 0.45 && Math.random() < 0.2) spawnSparkles(4);
  }

  /* ══════════════════════════════════════════════════
     SUELO / ESCENARIO
  ══════════════════════════════════════════════════ */
  function drawStage() {
    // Suelo con efecto de tablón
    var gradient = ctx.createLinearGradient(0, CH*0.75, 0, CH);
    gradient.addColorStop(0, "#1a0a05");
    gradient.addColorStop(1, "#0a0505");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, CH*0.75, CW, CH*0.25);

    // Líneas del tablón
    ctx.strokeStyle = "rgba(255,215,0,0.05)";
    ctx.lineWidth = 1;
    for (var i = 0; i < CW; i += 60) {
      ctx.beginPath();
      ctx.moveTo(i, CH*0.75);
      ctx.lineTo(i, CH);
      ctx.stroke();
    }

    // Línea de escenario
    ctx.strokeStyle = "rgba(255,215,0,0.15)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, CH*0.75);
    ctx.lineTo(CW, CH*0.75);
    ctx.stroke();

    // Spotlight en el suelo
    var sg = ctx.createRadialGradient(mj.x, CH*0.75, 0, mj.x, CH*0.75, 80);
    sg.addColorStop(0, "rgba(255,215,0,0.12)");
    sg.addColorStop(1, "transparent");
    ctx.beginPath();
    ctx.ellipse(mj.x, CH*0.75, 80, 30, 0, 0, Math.PI*2);
    ctx.fillStyle = sg;
    ctx.fill();
  }

  function drawSpotlight() {
    var sg = ctx.createRadialGradient(mj.x, 0, 0, mj.x, 0, 350);
    sg.addColorStop(0, "rgba(255,215,0,0.04)");
    sg.addColorStop(1, "transparent");
    ctx.fillStyle = sg;
    ctx.fillRect(0, 0, CW, CH);
  }

  /* ══════════════════════════════════════════════════
     LOOP PRINCIPAL
  ══════════════════════════════════════════════════ */
  var floorY;

  function update() {
    floorY = CH * 0.75 - 5;

    // Movimiento con teclado
    if (mj.keys["ArrowLeft"]  || mj.keys["a"]) { mj.x -= mj.speed; mj.facing = -1; }
    if (mj.keys["ArrowRight"] || mj.keys["d"]) { mj.x += mj.speed; mj.facing =  1; }
    if (mj.keys["ArrowUp"]    || mj.keys["w"]) { mj.y -= mj.speed; }
    if (mj.keys["ArrowDown"]  || mj.keys["s"]) { mj.y += mj.speed; }

    // Límites
    mj.x = Math.max(50, Math.min(CW - 50, mj.x));
    mj.y = Math.max(CH * 0.2, Math.min(floorY, mj.y));

    // Avanzar frame de animación
    var moveDef = MOVES[mj.move] || MOVES["idle"];
    mj.frame = (mj.frame + 1) % moveDef.frames;

    // Sparkles
    mj.sparkles = mj.sparkles.filter(function(s) {
      s.x += s.vx; s.y += s.vy; s.vy += 0.05;
      s.life -= 0.025;
      return s.life > 0;
    });

    // Polvo de pies
    mj.footDust = mj.footDust.filter(function(d) {
      d.x += d.vx; d.y += d.vy;
      d.life -= 0.04;
      return d.life > 0;
    });
  }

  function render() {
    ctx.clearRect(0, 0, CW, CH);

    // Fondo del escenario
    var bg = ctx.createLinearGradient(0, 0, 0, CH);
    bg.addColorStop(0, "#050505");
    bg.addColorStop(1, "#0d0505");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, CW, CH);

    // Spotlight desde arriba
    drawSpotlight();

    // Suelo
    drawStage();

    // Polvo de pies
    mj.footDust.forEach(function(d) {
      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r * d.life, 0, Math.PI*2);
      ctx.fillStyle = "rgba(200,149,108," + d.life * 0.4 + ")";
      ctx.fill();
    });

    // Personaje
    var t = mj.frame / (MOVES[mj.move] || MOVES["idle"]).frames;
    drawMJ(mj.x, mj.y, mj.facing, mj.move, mj.frame);

    // Sparkles
    mj.sparkles.forEach(function(s) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r * s.life, 0, Math.PI*2);
      ctx.fillStyle = s.hue === 45
        ? "rgba(255,215,0," + s.life + ")"
        : "rgba(255,80,80," + s.life + ")";
      ctx.fill();
    });

    // HUD de movimiento actual
    if (mj.move !== "idle") {
      ctx.font = "bold 11px monospace";
      ctx.fillStyle = "rgba(255,215,0,0.4)";
      ctx.fillText("MOVE: " + MOVES[mj.move].name, 14, CH - 14);
    }

    ctx.font = "10px monospace";
    ctx.fillStyle = "rgba(255,215,0,0.2)";
    ctx.fillText("← → ↑ ↓ mover   |   1-8 bailar   |   0 stop", CW/2 - 130, CH - 12);

    requestAnimationFrame(loop);
  }

  function loop() {
    update();
    render();
  }

  /* ── Inicializar posición ───────────────────────── */
  function init() {
    CW = canvas.offsetWidth  || 800;
    CH = canvas.offsetHeight || 480;
    canvas.width  = CW;
    canvas.height = CH;
    mj.x = CW / 2;
    mj.y = CH * 0.75 - 5;
    // Resaltar idle en panel
    document.querySelectorAll(".move-item").forEach(function(el){
      el.classList.toggle("active", el.dataset.key === "0");
    });
    requestAnimationFrame(loop);
  }

  // Esperar a que el DOM esté listo y el canvas tenga tamaño
  if (document.readyState === "complete") { init(); }
  else { window.addEventListener("load", init); }

  // Exponer para app.js
  window.Dancer = {
    setMove: setMove,
    getMJ: function(){ return mj; },
  };

})();
