# Requirements Document

## Introduction

Rediseño del modelo del personaje Michael Jackson en `dancer.js` para que adopte una estética pixel art retro estilo 16-bit, fiel a una imagen de referencia de sprite que muestra: traje negro (chaqueta + pantalón), camisa blanca con cuello abierto, sombrero fedora negro, puños/cuffs blancos visibles, pose dinámica de baile con piernas separadas y brazos extendidos, sombra en el suelo. El sistema de animación (poses por movimiento) se mantiene; únicamente cambia la función de dibujado de partes del cuerpo y la paleta de colores. El stack sigue siendo Canvas 2D API con JavaScript vanilla, sin dependencias.

## Glossary

- **Dancer**: El módulo IIFE definido en `dancer.js` que controla el personaje MJ y su lógica de animación.
- **Model**: El conjunto de funciones de dibujado que renderizan visualmente al personaje MJ sobre el canvas (`drawHead`, `drawTorso`, `drawArm`, `drawLeg`, `drawBelt`, `drawMJ`).
- **Pixel_Block**: Rectángulo de tamaño fijo (múltiplo de un pixel base, por ejemplo 3×3 px) usado como unidad mínima de dibujado en estilo pixel art.
- **Palette**: Conjunto de colores definidos en el objeto `C` dentro de `dancer.js` que dictan el look del personaje.
- **Pose**: La configuración de ángulos y posiciones de miembros que define un paso de baile en un frame concreto.
- **Shadow**: La elipse oscura dibujada bajo el personaje para simular su sombra en el suelo.
- **Cuff**: Puño blanco visible en la muñeca/antebrazo del personaje, rasgo icónico del sprite de referencia.
- **Fedora**: Sombrero de ala plana negro tipo fedora, parte característica del atuendo del sprite.
- **Canvas**: El elemento `<canvas id="stage-canvas">` sobre el que se renderiza el personaje.
- **Frame**: Una iteración del loop de animación; el contador `mj.frame` avanza uno por tick.

---

## Requirements

### Requirement 1: Paleta de colores pixel art

**User Story:** Como usuario, quiero que el personaje MJ tenga los colores del sprite pixel art de referencia, para que la apariencia visual sea fiel al estilo retro 16-bit.

#### Acceptance Criteria

1. THE Palette SHALL definir negro `#111111` para sombrero, chaqueta y pantalón.
2. THE Palette SHALL definir blanco `#FFFFFF` para camisa, puños (cuffs) y el guante derecho.
3. THE Palette SHALL definir `#c8956c` para el tono de piel del cuello y la cabeza.
4. THE Palette SHALL definir negro `#111111` para los zapatos.
5. THE Palette SHALL mantener `#ffd700` para el cinturón y los detalles dorados.
6. WHEN la Palette cambia respecto a la versión anterior, THE Dancer SHALL aplicar la nueva Palette en todas las funciones de dibujado sin afectar la lógica de animación.

---

### Requirement 2: Redibujado del torso con estilo pixel art

**User Story:** Como usuario, quiero que el torso del personaje use bloques rectangulares nítidos con contornos definidos, para que se vea como un sprite de 16 bits en lugar de formas suavizadas.

#### Acceptance Criteria

1. THE Model SHALL dibujar el torso como un rectángulo de chaqueta negra sin bordes redondeados (`borderRadius = 0`) o con radio ≤ 1px.
2. THE Model SHALL dibujar una franja vertical de camisa blanca en el centro del torso (ancho ≥ 4px) representando la apertura de la chaqueta.
3. THE Model SHALL dibujar el cinturón como una banda horizontal dorada de altura fija de 4px centrada en la cintura.
4. WHEN el Model dibuja el torso, THE Model SHALL usar solo colores de la Palette definida en el Requirement 1.

---

### Requirement 3: Redibujado del sombrero Fedora con pixel art

**User Story:** Como usuario, quiero que el sombrero del personaje represente fielmente el fedora negro del sprite de referencia, para reforzar el look icónico de MJ.

#### Acceptance Criteria

1. THE Model SHALL dibujar la copa del Fedora como un rectángulo negro (`#111111`) de proporciones similares al sprite de referencia (ancho ≥ 28px, alto ≥ 18px a escala del personaje).
2. THE Model SHALL dibujar el ala del Fedora como un rectángulo horizontal negro más ancho que la copa (extensión lateral ≥ 6px a cada lado de la copa) y de altura fija de 4–6px.
3. THE Model SHALL dibujar una banda de color en la unión ala-copa con al menos 2px de alto.
4. WHEN se ejecuta la animación `lean` o `spin`, THE Model SHALL rotar el Fedora junto con la cabeza manteniendo su posición relativa al cráneo.

---

### Requirement 4: Redibujado de brazos con Cuffs visibles

**User Story:** Como usuario, quiero que los brazos del personaje muestren los puños blancos (cuffs) en las muñecas, para que el atuendo sea fiel al sprite pixel art de referencia.

#### Acceptance Criteria

1. THE Model SHALL dibujar cada brazo con tres segmentos: manga superior (negra), antebrazo (negro) y cuff (blanco).
2. THE Model SHALL representar el Cuff como un rectángulo blanco de altura fija de 5–8px en el extremo distal del antebrazo, antes de la mano.
3. THE Model SHALL dibujar la mano/guante como un bloque cuadrado o elipse de 8–10px visible por encima del Cuff.
4. WHEN el brazo derecho está activo en la pose `crotch`, THE Model SHALL mantener el Cuff blanco visible aunque el brazo esté doblado.
5. THE Model SHALL usar `roundRect` con `borderRadius ≤ 2` o `fillRect` para todos los segmentos del brazo para preservar la estética pixel.

---

### Requirement 5: Redibujado de piernas con calcetines blancos y zapatos

**User Story:** Como usuario, quiero que las piernas del personaje muestren los calcetines blancos y zapatos negros del sprite de referencia, para mantener el look pixel art completo.

#### Acceptance Criteria

1. THE Model SHALL dibujar cada pierna con tres segmentos: muslo (negro), espinilla (negra) y calcetín (blanco).
2. THE Model SHALL representar el calcetín como un rectángulo blanco de altura fija de 8–12px.
3. THE Model SHALL dibujar el zapato como un rectángulo negro ligeramente más ancho que la espinilla (extensión lateral ≥ 3px a cada lado) con altura fija de 6–8px.
4. WHEN la pose activa es `toestand`, THE Model SHALL mostrar ambos zapatos con la punta hacia arriba usando una rotación ≤ -0.4 radianes.
5. THE Model SHALL usar `fillRect` o `roundRect` con `borderRadius ≤ 2` para todos los segmentos de las piernas.

---

### Requirement 6: Sombra en el suelo

**User Story:** Como usuario, quiero que el personaje proyecte una sombra elíptica en el suelo, para reforzar la percepción de profundidad igual que en el sprite de referencia.

#### Acceptance Criteria

1. THE Model SHALL dibujar una elipse oscura (`rgba(0,0,0,0.35)–rgba(0,0,0,0.5)`) bajo los pies del personaje en cada frame.
2. THE Shadow SHALL tener radio horizontal de 20–32px y radio vertical de 5–10px, escalado relativo al tamaño del cuerpo.
3. WHEN el personaje ejecuta `toestand` y su posición Y disminuye, THE Shadow SHALL reducir su radio horizontal proporcionalmente (mínimo 14px) para indicar elevación.
4. THE Shadow SHALL dibujarse antes que cualquier segmento del cuerpo para que quede siempre debajo del personaje.

---

### Requirement 7: Compatibilidad con el sistema de animación existente

**User Story:** Como desarrollador, quiero que el nuevo modelo pixel art sea compatible con todas las poses y movimientos ya implementados, para no romper la interactividad del proyecto.

#### Acceptance Criteria

1. THE Dancer SHALL renderizar correctamente el nuevo Model en los 9 movimientos definidos: `idle`, `moonwalk`, `thriller`, `lean`, `toestand`, `spin`, `robot`, `crotch`, `smooth`.
2. WHEN el usuario presiona las teclas `1`–`8` o `0`, THE Dancer SHALL transicionar al movimiento correspondiente sin artefactos visuales.
3. THE Model SHALL aceptar los mismos parámetros de entrada que las funciones originales (`hipAngle`, `kneeAngle`, `shoulderAngle`, `elbowAngle`, `toeUp`, `glove`, `hatAngle`, `jacketColor`) para que las poses existentes funcionen sin modificaciones.
4. IF el canvas es redimensionado, THEN THE Dancer SHALL redibujar el Model completo en el siguiente frame sin pérdida de calidad.
5. THE Dancer SHALL mantener la tasa de renderizado usando `requestAnimationFrame`, sin introducir `setInterval` ni bloqueos síncronos.

---

### Requirement 8: Estética pixel art coherente (sin anti-aliasing visual)

**User Story:** Como usuario, quiero que todo el modelo tenga la apariencia nítida y cuadrada de un sprite pixel art retro, sin degradados suavizados ni sombras de caja.

#### Acceptance Criteria

1. THE Model SHALL evitar el uso de `shadowBlur` o `shadowColor` en los segmentos del cuerpo del personaje.
2. THE Model SHALL usar únicamente colores sólidos (sin gradientes) para todos los segmentos del cuerpo, con excepción de los efectos de partículas y sparkles que son externos al Model.
3. THE Model SHALL limitar el uso de `arc`/`ellipse` a la cabeza, puños/manos y la sombra en el suelo; el resto de segmentos SHALL usar formas rectangulares.
4. WHERE el proyecto utiliza `ctx.imageSmoothingEnabled`, THE Canvas SHALL mantener `imageSmoothingEnabled = false` durante el dibujado del Model para preservar la nitidez pixel.
