---
inclusion: always
---

# Project Rules — MJ Landing Page

## Stack
- HTML5 + CSS3 + JavaScript vanilla (ES5/ES6 mix)
- Canvas 2D API (no WebGL)
- No frameworks, no bundler, no dependencies
- Files: index.html, style.css, bg.js, dancer.js, app.js, server.js

## Code Style
- Prefer `var` + `function` declarations inside IIFEs
- Arrow functions OK for short callbacks
- CSS: custom properties (--var), no preprocessors
- No TypeScript, no JSX
- Comments: only on complex logic blocks, 1 line max
- No console.log in production code

## Response Rules
- Skip theory/explanations unless asked
- Show only changed lines with minimal context (2 lines before/after)
- Never rewrite entire files unless explicitly requested
- Prefer strReplace over full rewrites
- No summaries at end of task unless asked

## File Structure
```
index.html   — markup + sections
style.css    — all styles + animations
bg.js        — background canvas particles
dancer.js    — MJ character + dance logic (Canvas 2D)
app.js       — UI controller (songs, reveals, scroll)
server.js    — Node http server (no npm)
```

## Canvas Patterns
- Always check `canvas.offsetWidth` before setting `canvas.width`
- Use `requestAnimationFrame` loops, never `setInterval` for rendering
- Clear with `ctx.clearRect(0,0,W,H)` each frame

## Server
- Pure Node.js `http` module, no express
- Port 3000, serves static files from `__dirname`
