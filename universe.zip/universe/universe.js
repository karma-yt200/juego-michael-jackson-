/**
 * COSMOS — Universe Engine
 * Motor de animación del universo: estrellas, nebulosas, agujeros negros,
 * galaxias, meteoritos, supernovas y efecto parallax con el scroll.
 */

(function () {
  'use strict';

  const canvas = document.getElementById('universe');
  const ctx    = canvas.getContext('2d');

  /* ── Tamaño ─────────────────────────────────────── */
  let W, H;
  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', () => { resize(); buildUniverse(); });

  /* ── Estado global ───────────────────────────────── */
  let mouseX = W / 2, mouseY = H / 2;
  let targetMX = W / 2, targetMY = H / 2;
  let scrollY  = 0;
  let isMoving = false;
  let moveTimer;
  let lastMX = mouseX, lastMY = mouseY;
  let velX = 0, velY = 0;

  /* ── Parámetros visuales ─────────────────────────── */
  const STAR_COUNT       = 600;
  const NEBULA_COUNT     = 5;
  const GALAXY_COUNT     = 3;
  const BLACKHOLE_COUNT  = 2;

  /* ═══════════════════════════════════════════════════
     CLASES DE OBJETOS CÓSMICOS
  ═══════════════════════════════════════════════════ */

  /* -- Estrella ------------------------------------ */
  class Star {
    constructor() { this.reset(true); }
    reset(init) {
      this.x     = Math.random() * W;
      this.y     = init ? Math.random() * H : -5;
      this.z     = Math.random() * 3 + 0.3;   // capa de parallax
      this.r     = Math.random() * 1.8 + 0.3;
      this.base  = this.r;
      this.color = randomStarColor();
      this.twinkleSpeed = Math.random() * 0.04 + 0.01;
      this.twinklePhase = Math.random() * Math.PI * 2;
      this.brightness = Math.random() * 0.5 + 0.5;
      this.trail  = [];
      this.trailLen = Math.floor(Math.random() * 6) + 2;
    }
    update(t) {
      this.twinklePhase += this.twinkleSpeed;
      const tw = Math.sin(this.twinklePhase);
      this.r = this.base * (0.7 + 0.3 * tw);
      this.brightness = 0.5 + 0.5 * Math.abs(tw);

      // Parallax suave con el mouse
      const px = (mouseX - W / 2) * 0.0001 * this.z;
      const py = (mouseY - H / 2) * 0.0001 * this.z;
      this.displayX = this.x + px * 40;
      this.displayY = this.y + py * 40 - (scrollY * 0.08 * this.z);

      // Trail si hay movimiento
      if (isMoving) {
        this.trail.unshift({ x: this.displayX, y: this.displayY });
        if (this.trail.length > this.trailLen) this.trail.pop();
      } else {
        if (this.trail.length) this.trail.pop();
      }
    }
    draw(t) {
      const cx = this.displayX, cy = this.displayY;
      if (cx < -20 || cx > W + 20 || cy < -20 || cy > H + 20) return;

      // Trail de movimiento
      if (this.trail.length > 1) {
        ctx.beginPath();
        ctx.moveTo(this.trail[0].x, this.trail[0].y);
        for (let i = 1; i < this.trail.length; i++) {
          ctx.lineTo(this.trail[i].x, this.trail[i].y);
        }
        ctx.strokeStyle = this.color.replace('hsl', 'hsla').replace(')', ',0.15)');
        ctx.lineWidth = this.r * 0.5;
        ctx.stroke();
      }

      // Halo de estrellas brillantes
      if (this.r > 1.2) {
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, this.r * 5);
        g.addColorStop(0, this.color.replace('hsl', 'hsla').replace(')', `,${0.15 * this.brightness})`));
        g.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.arc(cx, cy, this.r * 5, 0, Math.PI * 2);
        ctx.fillStyle = g;
        ctx.fill();
      }

      // Núcleo
      ctx.beginPath();
      ctx.arc(cx, cy, this.r, 0, Math.PI * 2);
      ctx.fillStyle = this.color.replace('hsl', 'hsla').replace(')', `,${this.brightness})`);
      ctx.fill();

      // Cruz de difracción en estrellas grandes
      if (this.r > 1.5) {
        const len = this.r * 4;
        ctx.strokeStyle = this.color.replace('hsl', 'hsla').replace(')', ',0.2)');
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        ctx.moveTo(cx - len, cy); ctx.lineTo(cx + len, cy);
        ctx.moveTo(cx, cy - len); ctx.lineTo(cx, cy + len);
        ctx.stroke();
      }
    }
  }

  /* -- Nebulosa ------------------------------------- */
  class Nebula {
    constructor() {
      this.x     = Math.random() * W;
      this.y     = Math.random() * H;
      this.w     = Math.random() * 400 + 200;
      this.h     = Math.random() * 300 + 150;
      this.angle = Math.random() * Math.PI;
      this.hue   = Math.random() * 360;
      this.opacity = Math.random() * 0.06 + 0.02;
      this.phase  = Math.random() * Math.PI * 2;
      this.speed  = Math.random() * 0.003 + 0.001;
      this.z      = Math.random() * 0.5 + 0.1;
    }
    draw(t) {
      this.phase += this.speed;
      const osc  = 0.7 + 0.3 * Math.sin(this.phase);
      const px   = (mouseX - W / 2) * 0.00005 * this.z * 60;
      const py   = (mouseY - H / 2) * 0.00005 * this.z * 60;
      const cx   = this.x + px - scrollY * 0.02 * this.z;
      const cy   = this.y + py;

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(this.angle + this.phase * 0.1);

      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, this.w / 2);
      g.addColorStop(0,   `hsla(${this.hue},80%,60%,${this.opacity * osc * 2})`);
      g.addColorStop(0.4, `hsla(${(this.hue + 40) % 360},70%,50%,${this.opacity * osc})`);
      g.addColorStop(1,   `hsla(${(this.hue + 80) % 360},60%,40%,0)`);

      ctx.beginPath();
      ctx.ellipse(0, 0, this.w / 2, this.h / 2, 0, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.restore();
    }
  }

  /* -- Galaxia espiral ----------------------------- */
  class Galaxy {
    constructor() {
      this.x      = Math.random() * W;
      this.y      = Math.random() * H;
      this.radius = Math.random() * 80 + 40;
      this.angle  = Math.random() * Math.PI * 2;
      this.speed  = (Math.random() * 0.002 + 0.001) * (Math.random() < 0.5 ? 1 : -1);
      this.hue    = Math.random() * 360;
      this.z      = 0.2 + Math.random() * 0.3;
      this.arms   = Math.floor(Math.random() * 2) + 2;
    }
    draw(t) {
      this.angle += this.speed;
      const px = (mouseX - W / 2) * 0.00005 * this.z * 60;
      const py = (mouseY - H / 2) * 0.00005 * this.z * 60;
      const cx = this.x + px;
      const cy = this.y + py - scrollY * 0.015 * this.z;

      ctx.save();
      ctx.translate(cx, cy);

      // Núcleo galáctico
      const core = ctx.createRadialGradient(0, 0, 0, 0, 0, this.radius * 0.3);
      core.addColorStop(0,   `hsla(${this.hue},80%,90%,0.35)`);
      core.addColorStop(0.5, `hsla(${this.hue},70%,60%,0.15)`);
      core.addColorStop(1,   `hsla(${this.hue},60%,40%,0)`);
      ctx.beginPath();
      ctx.arc(0, 0, this.radius * 0.3, 0, Math.PI * 2);
      ctx.fillStyle = core;
      ctx.fill();

      // Brazos espirales
      for (let arm = 0; arm < this.arms; arm++) {
        const armAngle = (arm / this.arms) * Math.PI * 2;
        ctx.beginPath();
        for (let i = 0; i < 200; i++) {
          const r   = (i / 200) * this.radius;
          const ang = armAngle + this.angle + i * 0.08;
          const px2 = r * Math.cos(ang);
          const py2 = r * Math.sin(ang);
          if (i === 0) ctx.moveTo(px2, py2);
          else ctx.lineTo(px2, py2);
        }
        const alpha = 0.03 + 0.02 * Math.sin(t * 0.001 + arm);
        ctx.strokeStyle = `hsla(${(this.hue + arm * 30) % 360},70%,80%,${alpha})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  /* -- Agujero Negro ------------------------------- */
  class BlackHole {
    constructor() {
      this.x      = Math.random() * W * 0.6 + W * 0.2;
      this.y      = Math.random() * H * 0.6 + H * 0.2;
      this.radius = Math.random() * 25 + 15;
      this.angle  = 0;
      this.speed  = Math.random() * 0.008 + 0.004;
      this.hue    = Math.random() > 0.5 ? 200 : 280;
      this.pulsePhase = Math.random() * Math.PI * 2;
    }
    draw(t) {
      this.angle += this.speed;
      this.pulsePhase += 0.02;
      const pulseMult = 1 + 0.1 * Math.sin(this.pulsePhase);

      // Disco de acreción
      for (let ring = 6; ring >= 1; ring--) {
        const r = this.radius * (ring * 0.6 + 0.5) * pulseMult;
        const alpha = (0.04 - ring * 0.005) * pulseMult;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle + ring * 0.3);
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.25, 0, 0, Math.PI * 2);
        ctx.strokeStyle = `hsla(${this.hue + ring * 20},80%,70%,${alpha})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
      }

      // Singularidad
      const gSing = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius * pulseMult);
      gSing.addColorStop(0,   'rgba(0,0,0,1)');
      gSing.addColorStop(0.7, 'rgba(0,0,0,0.95)');
      gSing.addColorStop(1,   `hsla(${this.hue},60%,40%,0)`);
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius * pulseMult * 1.2, 0, Math.PI * 2);
      ctx.fillStyle = gSing;
      ctx.fill();

      // Anillo de fotones
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius * pulseMult, 0, Math.PI * 2);
      ctx.strokeStyle = `hsla(${this.hue},90%,80%,0.6)`;
      ctx.lineWidth   = 1.5;
      ctx.stroke();

      // Efecto lente gravitacional (halo borroso)
      const gLens = ctx.createRadialGradient(this.x, this.y, this.radius, this.x, this.y, this.radius * 4);
      gLens.addColorStop(0, `hsla(${this.hue},70%,50%,0.08)`);
      gLens.addColorStop(1, 'transparent');
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius * 4, 0, Math.PI * 2);
      ctx.fillStyle = gLens;
      ctx.fill();
    }
  }

  /* -- Meteorito ----------------------------------- */
  class Meteorite {
    constructor() { this.reset(); }
    reset() {
      this.x     = Math.random() * W + W * 0.5;
      this.y     = Math.random() * H * 0.5 - 50;
      this.len   = Math.random() * 120 + 40;
      this.speed = Math.random() * 8 + 4;
      this.angle = Math.PI * (0.6 + Math.random() * 0.2);
      this.alpha = Math.random() * 0.7 + 0.3;
      this.r     = Math.random() * 2 + 0.5;
      this.active = false;
      this.life  = 0;
      this.maxLife = Math.random() * 60 + 30;
      this.hue   = Math.random() < 0.7 ? 200 : 50;
    }
    activate() {
      this.active = true;
      this.life   = 0;
      this.x      = Math.random() * W + W * 0.3;
      this.y      = -20;
    }
    update() {
      if (!this.active) return;
      this.x += Math.cos(this.angle) * this.speed;
      this.y += Math.sin(this.angle) * this.speed;
      this.life++;
      if (this.life > this.maxLife || this.y > H + 50) this.active = false;
    }
    draw() {
      if (!this.active) return;
      const fade = 1 - this.life / this.maxLife;
      const tailX = this.x - Math.cos(this.angle) * this.len;
      const tailY = this.y - Math.sin(this.angle) * this.len;

      const g = ctx.createLinearGradient(tailX, tailY, this.x, this.y);
      g.addColorStop(0, `hsla(${this.hue},80%,90%,0)`);
      g.addColorStop(1, `hsla(${this.hue},80%,98%,${this.alpha * fade})`);

      ctx.beginPath();
      ctx.moveTo(tailX, tailY);
      ctx.lineTo(this.x, this.y);
      ctx.strokeStyle = g;
      ctx.lineWidth   = this.r;
      ctx.stroke();

      // Cabeza brillante
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r * 2, 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${this.hue},80%,99%,${fade})`;
      ctx.fill();
    }
  }

  /* -- Supernova ----------------------------------- */
  class Supernova {
    constructor(x, y) {
      this.x     = x || Math.random() * W;
      this.y     = y || Math.random() * H;
      this.phase = 0;
      this.maxR  = Math.random() * 200 + 100;
      this.speed = Math.random() * 1.5 + 0.5;
      this.hue   = Math.random() * 60 + 20;
      this.done  = false;
    }
    update() {
      this.phase += this.speed;
      if (this.phase > 120) this.done = true;
    }
    draw() {
      const progress = this.phase / 120;
      const r        = this.maxR * Math.sin(progress * Math.PI);
      const alpha    = Math.max(0, 1 - progress * 1.5) * 0.6;

      // Anillos expansivos
      for (let i = 0; i < 3; i++) {
        const ri = r * (1 - i * 0.15);
        const g  = ctx.createRadialGradient(this.x, this.y, ri * 0.8, this.x, this.y, ri);
        g.addColorStop(0, `hsla(${this.hue + i * 30},90%,80%,0)`);
        g.addColorStop(0.7, `hsla(${this.hue + i * 30},90%,80%,${alpha * (1 - i * 0.3)})`);
        g.addColorStop(1,   `hsla(${this.hue + i * 30},80%,60%,0)`);
        ctx.beginPath();
        ctx.arc(this.x, this.y, ri, 0, Math.PI * 2);
        ctx.fillStyle = g;
        ctx.fill();
      }

      // Destello central (solo inicio)
      if (progress < 0.1) {
        const fl = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, 60);
        fl.addColorStop(0, `rgba(255,255,255,${0.9 * (1 - progress * 10)})`);
        fl.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.arc(this.x, this.y, 60, 0, Math.PI * 2);
        ctx.fillStyle = fl;
        ctx.fill();
      }
    }
  }

  /* -- Partícula de nebulosa interactiva ----------- */
  class NebulaParticle {
    constructor(x, y) {
      this.x     = x;
      this.y     = y;
      this.vx    = (Math.random() - 0.5) * 3;
      this.vy    = (Math.random() - 0.5) * 3 - 1;
      this.r     = Math.random() * 3 + 1;
      this.hue   = Math.random() * 360;
      this.alpha = 0.7;
      this.life  = 0;
      this.maxLife = Math.random() * 80 + 40;
      this.done  = false;
    }
    update() {
      this.x  += this.vx;
      this.y  += this.vy;
      this.vx *= 0.97;
      this.vy *= 0.97;
      this.vy -= 0.02;
      this.life++;
      this.alpha = 0.7 * (1 - this.life / this.maxLife);
      this.r    *= 0.99;
      if (this.life >= this.maxLife) this.done = true;
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${this.hue},80%,70%,${this.alpha})`;
      ctx.fill();
    }
  }

  /* ═══════════════════════════════════════════════════
     CONSTRUCCIÓN DEL UNIVERSO
  ═══════════════════════════════════════════════════ */
  let stars       = [];
  let nebulae     = [];
  let galaxies    = [];
  let blackHoles  = [];
  let meteorites  = [];
  let supernovas  = [];
  let nebulaParticles = [];

  function buildUniverse() {
    stars      = Array.from({ length: STAR_COUNT },      () => new Star());
    nebulae    = Array.from({ length: NEBULA_COUNT },    () => new Nebula());
    galaxies   = Array.from({ length: GALAXY_COUNT },    () => new Galaxy());
    blackHoles = Array.from({ length: BLACKHOLE_COUNT }, () => new BlackHole());
    meteorites = Array.from({ length: 12 },              () => new Meteorite());
  }
  buildUniverse();

  /* ═══════════════════════════════════════════════════
     INTERACTIVIDAD
  ═══════════════════════════════════════════════════ */

  // Spawneo aleatorio de meteoritos
  function spawnMeteorShower() {
    const inactive = meteorites.filter(m => !m.active);
    const count = Math.floor(Math.random() * 4) + 1;
    for (let i = 0; i < count; i++) {
      if (inactive[i]) inactive[i].activate();
    }
  }
  setInterval(spawnMeteorShower, 2500);

  // Supernovas aleatorias periódicas
  function spawnRandomSupernova() {
    const x = Math.random() * W;
    const y = Math.random() * H;
    supernovas.push(new Supernova(x, y));
  }
  setInterval(spawnRandomSupernova, 8000);

  // Click → supernova en posición del mouse
  document.addEventListener('click', (e) => {
    supernovas.push(new Supernova(mouseX, mouseY));
    // Partículas de nebulosa
    for (let i = 0; i < 20; i++) {
      nebulaParticles.push(new NebulaParticle(mouseX, mouseY));
    }
  });

  // Scroll
  window.addEventListener('scroll', () => {
    scrollY = window.scrollY;
  });

  // Mouse
  document.addEventListener('mousemove', (e) => {
    targetMX = e.clientX;
    targetMY = e.clientY;
    isMoving = true;
    clearTimeout(moveTimer);
    moveTimer = setTimeout(() => { isMoving = false; }, 150);
  });

  /* ═══════════════════════════════════════════════════
     HELPERS DE COLOR
  ═══════════════════════════════════════════════════ */
  function randomStarColor() {
    const palette = [
      'hsl(200,80%,95%)', // blanco-azulado
      'hsl(220,70%,90%)', // blanco
      'hsl(60,80%,90%)',  // amarillo-blanco
      'hsl(30,70%,85%)',  // naranja suave
      'hsl(0,60%,85%)',   // rojizo
      'hsl(180,60%,90%)', // cyan
    ];
    const weights = [0.35, 0.30, 0.15, 0.10, 0.05, 0.05];
    const r = Math.random();
    let acc = 0;
    for (let i = 0; i < palette.length; i++) {
      acc += weights[i];
      if (r < acc) return palette[i];
    }
    return palette[0];
  }

  /* ═══════════════════════════════════════════════════
     LOOP DE RENDERIZADO
  ═══════════════════════════════════════════════════ */
  let t = 0;
  let lastSupernovaSpawn = 0;

  function render(timestamp) {
    t = timestamp;

    // Suavizado del movimiento del mouse
    const ease = 0.12;
    mouseX += (targetMX - mouseX) * ease;
    mouseY += (targetMY - mouseY) * ease;
    velX = targetMX - mouseX;
    velY = targetMY - mouseY;

    // Fondo: degradado desde negro absoluto
    const gBg = ctx.createRadialGradient(
      mouseX, mouseY, 0,
      mouseX, mouseY, Math.max(W, H) * 0.9
    );
    const bgBrightness = Math.min(0.15, (Math.abs(velX) + Math.abs(velY)) * 0.003);
    gBg.addColorStop(0,   `hsla(230,40%,${4 + bgBrightness * 10}%,1)`);
    gBg.addColorStop(0.3, `hsla(240,30%,${2 + bgBrightness * 4}%,1)`);
    gBg.addColorStop(1,   'hsl(0,0%,0%)');
    ctx.fillStyle = gBg;
    ctx.fillRect(0, 0, W, H);

    // Nebulosas (fondo)
    nebulae.forEach(n => n.draw(t));

    // Galaxias
    galaxies.forEach(g => g.draw(t));

    // Agujeros negros
    blackHoles.forEach(b => b.draw(t));

    // Estrellas
    stars.forEach(s => { s.update(t); s.draw(t); });

    // Meteoritos
    meteorites.forEach(m => { m.update(); m.draw(); });

    // Supernovas
    supernovas = supernovas.filter(s => !s.done);
    supernovas.forEach(s => { s.update(); s.draw(); });

    // Partículas de nebulosa
    nebulaParticles = nebulaParticles.filter(p => !p.done);
    nebulaParticles.forEach(p => { p.update(); p.draw(); });

    // Zona de iluminación alrededor del mouse (nave)
    const lightR = 180 + Math.sin(t * 0.002) * 20;
    const gLight = ctx.createRadialGradient(mouseX, mouseY, 0, mouseX, mouseY, lightR);
    gLight.addColorStop(0,   'rgba(0,229,255,0.04)');
    gLight.addColorStop(0.5, 'rgba(0,100,200,0.02)');
    gLight.addColorStop(1,   'transparent');
    ctx.beginPath();
    ctx.arc(mouseX, mouseY, lightR, 0, Math.PI * 2);
    ctx.fillStyle = gLight;
    ctx.fill();

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);

  /* ── Exportar mouseX / mouseY para app.js ─────── */
  window.Universe = {
    get mouseX() { return mouseX; },
    get mouseY() { return mouseY; },
    get velX()   { return velX; },
    get velY()   { return velY; },
    spawnSupernova: (x, y) => supernovas.push(new Supernova(x, y)),
  };

})();
