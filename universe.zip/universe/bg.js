/**
 * bg.js — Fondo animado: notas musicales, estrellas y partículas doradas
 */
(function () {
  const canvas = document.getElementById('bg-canvas');
  const ctx    = canvas.getContext('2d');
  let W, H;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // Partículas de fondo
  const NOTES = ['♪','♫','♩','♬','♭','♮'];
  const particles = Array.from({ length: 60 }, () => createParticle(true));

  function createParticle(init) {
    return {
      x:     Math.random() * (typeof W !== 'undefined' ? W : 1920),
      y:     init ? Math.random() * (typeof H !== 'undefined' ? H : 1080) : (typeof H !== 'undefined' ? H + 20 : 1080),
      size:  Math.random() * 14 + 8,
      speed: Math.random() * 0.4 + 0.1,
      alpha: Math.random() * 0.12 + 0.03,
      drift: (Math.random() - 0.5) * 0.3,
      note:  NOTES[Math.floor(Math.random() * NOTES.length)],
      isNote: Math.random() > 0.5,
      hue:   Math.random() > 0.6 ? 45 : 0,   // gold o red
    };
  }

  function render() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach((p, i) => {
      p.y    -= p.speed;
      p.x    += p.drift;
      p.alpha = Math.max(0, p.alpha - 0.00005);

      if (p.y < -30) {
        particles[i] = createParticle(false);
        return;
      }

      if (p.isNote) {
        ctx.font = `${p.size}px serif`;
        ctx.fillStyle = p.hue === 45
          ? `rgba(255,215,0,${p.alpha})`
          : `rgba(200,50,50,${p.alpha})`;
        ctx.fillText(p.note, p.x, p.y);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = p.hue === 45
          ? `rgba(255,215,0,${p.alpha * 0.6})`
          : `rgba(255,255,255,${p.alpha * 0.4})`;
        ctx.fill();
      }
    });

    requestAnimationFrame(render);
  }

  render();
})();
