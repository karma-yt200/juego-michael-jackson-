﻿/**
 * app.js — Controlador principal MJ Landing Page
 * Maneja: reveal on scroll, reproductor visual, controles de canción, intro.
 */
(function () {
  "use strict";

  /* ── Intro overlay ─────────────────────────────── */
  var introEl = document.getElementById("intro-overlay");
  if (introEl) {
    introEl.addEventListener("animationend", function() {
      introEl.style.display = "none";
    });
  }

  /* ── Reveal on scroll ──────────────────────────── */
  var revealEls = document.querySelectorAll("[data-reveal]");
  var observer  = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) entry.target.classList.add("visible");
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  revealEls.forEach(function(el) { observer.observe(el); });

  /* ── Selección de canción ──────────────────────── */
  var songBtns   = document.querySelectorAll(".song-btn");
  var playBtn    = document.getElementById("play-btn");
  var eqEl       = document.getElementById("equalizer");
  var currentSong = "thriller";
  var isPlaying   = false;

  // Configuración visual de cada canción
  var SONGS = {
    thriller: { label: "Thriller",        color: "#cc3300", tempo: 0.4  },
    billie:   { label: "Billie Jean",     color: "#0044cc", tempo: 0.5  },
    smooth:   { label: "Smooth Criminal", color: "#ffffff", tempo: 0.55 },
    beat:     { label: "Beat It",         color: "#cc0000", tempo: 0.6  },
    black:    { label: "Black or White",  color: "#ffaa00", tempo: 0.45 },
  };

  songBtns.forEach(function(btn) {
    btn.addEventListener("click", function() {
      songBtns.forEach(function(b){ b.classList.remove("active"); });
      btn.classList.add("active");
      currentSong = btn.dataset.song;
      if (isPlaying) applySongTheme(currentSong);
    });
  });

  function applySongTheme(song) {
    var cfg = SONGS[song] || SONGS.thriller;
    // Colorear ecualizador
    document.querySelectorAll(".eq-bar").forEach(function(bar) {
      bar.style.background = "linear-gradient(to top, " + cfg.color + ", #ffd700)";
    });
    // Ajustar velocidad de animación
    document.querySelectorAll(".eq-bar").forEach(function(bar, i) {
      bar.style.animationDuration = (cfg.tempo + Math.random() * 0.2) + "s";
    });
  }

  /* ── Beat visual sincronizado (sin audio real) ─── */
  var beatInterval = null;

  function startBeat(song) {
    var cfg   = SONGS[song] || SONGS.thriller;
    var bpm   = 120;  // tempo visual simulado
    var delay = (60 / bpm) * 1000 * cfg.tempo;

    eqEl.classList.add("playing");
    applySongTheme(song);

    // Pulso en el escenario cada beat
    beatInterval = setInterval(function() {
      pulseStageLights();
      spawnBeatParticles();
    }, delay * 2);
  }

  function stopBeat() {
    eqEl.classList.remove("playing");
    clearInterval(beatInterval);
    beatInterval = null;
  }

  playBtn.addEventListener("click", function() {
    isPlaying = !isPlaying;
    if (isPlaying) {
      playBtn.textContent = "⏸ Pausar";
      startBeat(currentSong);
    } else {
      playBtn.textContent = "▶ Reproducir";
      stopBeat();
    }
  });

  /* ── Pulso de luces de escenario ───────────────── */
  function pulseStageLights() {
    var lights = document.querySelectorAll(".stage-light");
    lights.forEach(function(l) {
      l.style.opacity = "1";
      setTimeout(function(){ l.style.opacity = ""; }, 150);
    });
  }

  /* ── Partículas de beat en el escenario ─────────── */
  var stageCanvas = document.getElementById("stage-canvas");

  function spawnBeatParticles() {
    if (!stageCanvas || !window.Dancer) return;
    var mj = window.Dancer.getMJ();
    // Sparkles sync con el beat
    for (var i = 0; i < 5; i++) {
      var el = document.createElement("div");
      var x  = mj.x + stageCanvas.getBoundingClientRect().left + (Math.random()-0.5)*60;
      var y  = mj.y + stageCanvas.getBoundingClientRect().top  - Math.random()*80;
      el.style.cssText = [
        "position:fixed",
        "left:" + x + "px",
        "top:" + y + "px",
        "width:6px",
        "height:6px",
        "border-radius:50%",
        "background:" + (SONGS[currentSong] ? SONGS[currentSong].color : "#ffd700"),
        "pointer-events:none",
        "z-index:9999",
        "animation:beatDot 0.6s ease forwards",
      ].join(";");
      document.body.appendChild(el);
      el.addEventListener("animationend", function(){ this.remove(); }.bind(el));
    }
  }

  /* ── Inyectar animación beat dot ───────────────── */
  var beatStyle = document.createElement("style");
  beatStyle.textContent = [
    "@keyframes beatDot {",
    "  0%   { opacity:0.9; transform:translate(0,0) scale(1); }",
    "  100% { opacity:0;   transform:translate(" + "var(--bx,0)" + "," + "var(--by,-40px)" + ") scale(0.2); }",
    "}",
  ].join("\n");
  document.head.appendChild(beatStyle);

  /* ── Clicks en panel de moves → cambiar baile ─── */
  document.querySelectorAll(".move-item").forEach(function(el) {
    el.addEventListener("click", function() {
      var key  = el.dataset.key;
      var map  = { "1":"moonwalk","2":"thriller","3":"lean","4":"toestand","5":"spin","6":"robot","7":"crotch","8":"smooth","0":"idle" };
      if (window.Dancer && map[key]) {
        window.Dancer.setMove(map[key]);
      }
    });
  });

  /* ── Clicks en botones de song desde hero ──────── */
  var heroCta = document.querySelector("#hero .btn-primary");
  if (heroCta) {
    heroCta.addEventListener("click", function(e) {
      e.preventDefault();
      // Auto-play el ecualizador al hacer click en "Bailar Ahora"
      if (!isPlaying && playBtn) {
        playBtn.click();
      }
      var danceSection = document.getElementById("dance");
      if (danceSection) danceSection.scrollIntoView({ behavior: "smooth" });
    });
  }

  /* ── Scroll progress bar ───────────────────────── */
  var progressBar = document.createElement("div");
  progressBar.style.cssText = [
    "position:fixed",
    "top:0",
    "left:0",
    "height:2px",
    "width:0%",
    "background:linear-gradient(90deg,#cc0000,#ffd700,#cc0000)",
    "z-index:99998",
    "transition:width 0.1s linear",
    "box-shadow:0 0 6px #ffd700",
  ].join(";");
  document.body.appendChild(progressBar);

  window.addEventListener("scroll", function() {
    var pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
    progressBar.style.width = Math.min(100, pct) + "%";
  });

  /* ── Navbar smooth scroll ──────────────────────── */
  document.querySelectorAll("#navbar a").forEach(function(a) {
    a.addEventListener("click", function(e) {
      var href = a.getAttribute("href");
      if (href && href.startsWith("#")) {
        e.preventDefault();
        var target = document.querySelector(href);
        if (target) target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  /* ── Tilt 3D en tarjetas ───────────────────────── */
  document.querySelectorAll(".album-card, .legacy-card").forEach(function(card) {
    card.addEventListener("mousemove", function(e) {
      var rect = card.getBoundingClientRect();
      var relX = (e.clientX - rect.left) / rect.width  - 0.5;
      var relY = (e.clientY - rect.top)  / rect.height - 0.5;
      card.style.transform = "perspective(600px) rotateX(" + (-relY*10) + "deg) rotateY(" + (relX*10) + "deg) translateY(-6px)";
    });
    card.addEventListener("mouseleave", function() {
      card.style.transform = "";
      card.style.transition = "transform 0.5s ease";
      setTimeout(function(){ card.style.transition = ""; }, 500);
    });
  });

  /* ── Inicialización: marcar idle activo ────────── */
  var idleItem = document.querySelector(".move-item[data-key='0']");
  if (idleItem) idleItem.classList.add("active");

})();
